<?php
$label = $sectionData['label'] ?? '';
$title = $sectionData['title'] ?? '';
$subtitle = $sectionData['subtitle'] ?? '';
$backgroundImage = $sectionData['background_image'] ?? '';
$primaryLabel = $sectionData['primary_button_label'] ?? '';
$primaryUrl = $sectionData['primary_button_url'] ?? '#';
$secondaryLabel = $sectionData['secondary_button_label'] ?? '';
$secondaryUrl = $sectionData['secondary_button_url'] ?? '#';
$pillars = is_array($sectionData['pillars'] ?? null) ? $sectionData['pillars'] : [];
?>

<section class="hero hero--premium hero--home" aria-labelledby="home-hero-title">
    <div
        class="hero__bg"
        style="background-image:linear-gradient(110deg, rgba(26,60,94,.92) 0%, rgba(15,38,68,.86) 58%, rgba(26,60,94,.92) 100%), url('<?= htmlspecialchars($backgroundImage, ENT_QUOTES, 'UTF-8') ?>');">
    </div>

    <div class="container">
        <div class="hero__content" data-animate>
            <?php if ($label !== ''): ?>
                <span class="section-label hero__label"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></span>
            <?php endif; ?>

            <?php if ($title !== ''): ?>
                <h1 id="home-hero-title"><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h1>
            <?php endif; ?>

            <?php if ($subtitle !== ''): ?>
                <p class="hero__subtitle"><?= htmlspecialchars($subtitle, ENT_QUOTES, 'UTF-8') ?></p>
            <?php endif; ?>

            <div class="hero__actions">
                <?php if ($primaryLabel !== ''): ?>
                    <a href="<?= htmlspecialchars($primaryUrl, ENT_QUOTES, 'UTF-8') ?>" class="btn btn--accent btn--lg">
                        <?= htmlspecialchars($primaryLabel, ENT_QUOTES, 'UTF-8') ?>
                    </a>
                <?php endif; ?>

                <?php if ($secondaryLabel !== ''): ?>
                    <a href="<?= htmlspecialchars($secondaryUrl, ENT_QUOTES, 'UTF-8') ?>" class="btn btn--outline-white btn--lg">
                        <?= htmlspecialchars($secondaryLabel, ENT_QUOTES, 'UTF-8') ?>
                    </a>
                <?php endif; ?>
            </div>

            <?php if ($pillars !== []): ?>
                <div class="hero__pillars" role="list" aria-label="Domaines d'expertise">
                    <?php foreach ($pillars as $pillar): ?>
                        <span role="listitem"><?= htmlspecialchars((string) $pillar, ENT_QUOTES, 'UTF-8') ?></span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>