<?php
$currentModule = $module ?? 'dashboard';
$currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?? '';

$moduleExists = static function (string $moduleName): bool {
    $modulePath = ROOT_PATH . '/modules/' . $moduleName . '/accueil.php';

    return is_file($modulePath);
};

/**
 * Titres de section = ton conversationnel (« ce que vous faites »).
 * Libellés d’entrée = courts pour éviter la coupure en sidebar étroite ; le title reprend la formulation complète.
 */
$menuGroups = [
    'Par ici, c’est clair' => [
        ['module' => 'dashboard', 'label' => 'Vue d’ensemble', 'title' => 'Tableau de bord — votre activité en un coup d’œil', 'icon' => 'fas fa-gauge-high'],
    ],
    'Vous avancez, étape par étape' => [
        ['module' => 'commencer', 'label' => 'Par où commencer', 'title' => 'Démarrer : premiers réglages et repères', 'icon' => 'fas fa-rocket'],
        ['module' => 'positionnement', 'label' => 'Votre position', 'title' => 'Se positionner sur votre marché', 'icon' => 'fas fa-layer-group'],
        ['module' => 'offre', 'label' => 'Ce que vous proposez', 'title' => 'Votre offre et votre promesse', 'icon' => 'fas fa-gift'],
        ['module' => 'attirer', 'label' => 'Être trouvé', 'title' => 'Être visible : SEO et visibilité', 'icon' => 'fas fa-magnifying-glass-chart'],
        ['module' => 'capture', 'label' => 'Attirer des demandes', 'title' => 'Capter des contacts et leads', 'icon' => 'fas fa-magnet', 'aliases' => ['capturer']],
        ['module' => 'convertir', 'label' => 'Conclure', 'title' => 'Signer des clients, conversion', 'icon' => 'fas fa-arrow-trend-up'],
        ['module' => 'optimiser', 'label' => 'Faire mieux', 'title' => 'Améliorer vos résultats', 'icon' => 'fas fa-chart-line'],
    ],
    'Votre site, vos textes' => [
        ['module' => 'cms-hub', 'label' => 'Pages & contenus', 'title' => 'Contenu et pages du site', 'icon' => 'fas fa-file-lines'],
    ],
    'Vos contacts & suivi' => [
        ['module' => 'crm-hub', 'label' => 'Contacts & suivi', 'title' => 'CRM et contacts', 'icon' => 'fas fa-address-book'],
    ],
    'Relances & visibilité' => [
        ['module' => 'marketing-hub', 'label' => 'Marketing & relances', 'title' => 'Marketing et automatisations', 'icon' => 'fas fa-bolt'],
    ],
    'Biens, secteurs, local' => [
        ['module' => 'properties-hub', 'label' => 'Annonces & secteurs', 'title' => 'Propriétés et secteurs', 'icon' => 'fas fa-house'],
        ['module' => 'annuaire-local', 'label' => 'Annuaire local', 'title' => 'Fiches et annuaire local', 'icon' => 'fas fa-store'],
    ],
    'Boîte à outils' => [
        ['module' => 'outils-hub', 'label' => 'Outils & exports', 'title' => 'Boîte à outils : téléchargements, scripts, ressources', 'icon' => 'fas fa-toolbox'],
        ['module' => 'checklist', 'label' => 'Checklist client', 'title' => 'Checklist de verification partageable avec le client', 'icon' => 'fas fa-list-check'],
    ],
    'Votre compte' => [
        ['module' => 'profil', 'label' => 'Mon profil', 'title' => 'Profil et identité', 'icon' => 'fas fa-user-gear'],
        ['module' => 'site', 'label' => 'Site public', 'title' => 'Aperçu et réglages du site public', 'icon' => 'fas fa-globe'],
        ['module' => 'parametres', 'label' => 'Paramètres', 'title' => 'Paramètres techniques et messagerie', 'icon' => 'fas fa-gear'],
    ],
];

$authUser = Auth::user();
if (($authUser['role'] ?? '') === 'superadmin') {
    $menuGroups['Votre compte'][] = ['module' => 'superadmin', 'label' => 'Superadmin', 'title' => 'Superadmin — modules et accès en direct', 'icon' => 'fas fa-crown'];
}
?>
<nav class="sidebar-nav">
    <ul class="sidebar-menu">
        <?php foreach ($menuGroups as $sectionLabel => $items): ?>
            <?php
            $visibleItems = array_values(array_filter($items, static function (array $item) use ($moduleExists): bool {
                if (isset($item['url'])) {
                    return true;
                }

                return $moduleExists((string) ($item['module'] ?? ''));
            }));

            if ($visibleItems === []) {
                continue;
            }
            ?>
            <li class="sidebar-section-head">
                <span class="nav-section-label"><?= htmlspecialchars($sectionLabel, ENT_QUOTES, 'UTF-8') ?></span>
            </li>
            <?php foreach ($visibleItems as $item):
                $targetUrl = $item['url'] ?? ('/admin?module=' . rawurlencode($item['module']));
                $aliases = $item['aliases'] ?? [];
                $isActive = isset($item['url'])
                    ? (rtrim($currentPath, '/') === rtrim((string) $item['url'], '/'))
                    : ($currentModule === $item['module'] || in_array($currentModule, $aliases, true));
                $tooltip = (string) ($item['title'] ?? $item['label'] ?? '');
                ?>
                <li>
                    <a href="<?= htmlspecialchars($targetUrl, ENT_QUOTES, 'UTF-8') ?>"
                       class="menu-item<?= $isActive ? ' active' : '' ?>"
                       data-module="<?= htmlspecialchars((string) ($item['module'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                       data-tooltip="<?= htmlspecialchars($tooltip, ENT_QUOTES, 'UTF-8') ?>"
                       title="<?= htmlspecialchars($tooltip, ENT_QUOTES, 'UTF-8') ?>"
                       style="position: relative;">
                        <span class="menu-icon"><i class="<?= htmlspecialchars((string) $item['icon'], ENT_QUOTES, 'UTF-8') ?>"></i></span>
                        <span class="menu-label"><?= htmlspecialchars((string) ($item['label'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </ul>
</nav>
